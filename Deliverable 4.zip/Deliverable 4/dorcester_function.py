import pandas as pd
import numpy as np

def Dorcester_precincts(df):
    columns = df.columns.to_list()
    index = columns.index("WP")
    
    data_array = df.to_numpy()
    
    d_precs_int = [802, 806, 708, 707, 710, 709, 710, 1305, 1306, 1307, 1308, 1309, 1303, 1310, 1501, 1503, 1504, 1506, 1507, 1508, 1509, 1602, 1604, 1605, 1606, 1607, 1608, 1609, 1610, 1611, 1612, 1713, 115]
    d_precs = [str(i) for i in d_precs_int]
    rows = []
    for i in range(np.shape(data_array)[0]):
        current_p = str(int(data_array[i, index]))
        if current_p in d_precs:
            rows.append(data_array[i].tolist())
    
    Dorcester_df = pd.DataFrame(np.asarray(rows), columns = df.columns)
    Dorcester_df["WP"] = Dorcester_df["WP"].astype('Int64')
    return Dorcester_df